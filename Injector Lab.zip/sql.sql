Drop Database If Exists theinjector;
CREATE DATABASE theinjector;
USE theinjector;
CREATE TABLE users (id int(225) NOT NULL, uname varchar(108), pass varchar(100));
insert into users (id, uname, pass) values ('1', 'user', '1234');
insert into users (id, uname, pass) values ('2', 'admin', 'password');
insert into users (id, uname, pass) values ('3', 'root', 'root');
insert into users (id, uname, pass) values ('4', 'cyberbullet', 'cyberbullet');
insert into users (id, uname, pass) values ('5', 'attack', 'attacker');
CREATE TABLE posts (id int(225) NOT NULL, title varchar(30), content varchar(108));
insert into posts (id, title, content) values ('1', 'SQL Injection', 'SQL injection is a web security vulnerability that allows an attacker to interfere with the queries that an application makes to its database. It generally allows an attacker to view data that they are not normally able to retrieve. This might include data belonging to other users, or any other data that the application itself is able to access. In many cases, an attacker can modify or delete this data, causing persistent changes to the application's content or behavior.

In some situations, an attacker can escalate an SQL injection attack to compromise the underlying server or other back-end infrastructure, or perform a denial-of-service attack.');
insert into posts (id, title, content) values ('2', 'Cross Site Scripting(XSS)', 'Cross-site scripting (also known as XSS) is a web security vulnerability that allows an attacker to compromise the interactions that users have with a vulnerable application. It allows an attacker to circumvent the same origin policy, which is designed to segregate different websites from each other. Cross-site scripting vulnerabilities normally allow an attacker to masquerade as a victim user, to carry out any actions that the user is able to perform, and to access any of the user's data. If the victim user has privileged access within the application, then the attacker might be able to gain full control over all of the application's functionality and data.');
insert into posts (id, title, content) values ('3', 'DDOS', 'A distributed denial-of-service (DDoS) attack is a malicious attempt to disrupt the normal traffic of a targeted server, service or network by overwhelming the target or its surrounding infrastructure with a flood of Internet traffic.

DDoS attacks achieve effectiveness by utilizing multiple compromised computer systems as sources of attack traffic. Exploited machines can include computers and other networked resources such as IoT devices.

From a high level, a DDoS attack is like an unexpected traffic jam clogging up the highway, preventing regular traffic from arriving at its destination.

');
insert into posts (id, title, content) values ('4', 'File Inclusion', 'A file inclusion vulnerability is a type of webvulnerability that is most commonly found to affect web applications that rely on a scripting run time. This issue is caused when an application builds a path to executable code using an attacker-controlled variable in a way that allows the attacker to control which file is executed at run time. A file include vulnerability is distinct from a generic directory traversal attack, in that directory traversal is a way of gaining unauthorized file system access, and a file inclusion vulnerability subverts how an application loads code for execution. Successful exploitation of a file inclusion vulnerability will result in remote code execution on the web server that runs the affected web application. An attacker can use remote code execution to create a web shell on the web server, which can be used for website defacement.');
insert into posts (id, title, content) values ('5', 'Command Injection', 'Command injection is an attack in which the goal is execution of arbitrary commands on the host operating system via a vulnerable application. Command injection attacks are possible when an application passes unsafe user supplied data (forms, cookies, HTTP headers etc.) to a system shell. In this attack, the attacker-supplied operating system commands are usually executed with the privileges of the vulnerable application. Command injection attacks are possible largely due to insufficient input validation.
<br>
This attack differs from Code Injection, in that code injection allows the attacker to add their own code that is then executed by the application. In Command Injection, the attacker extends the default functionality of the application, which execute system commands, without the necessity of injecting code.

');
insert into posts (id, title, content) values ('6', 'IDOR', 'Insecure direct object references (IDOR) are a type of access control vulnerability that arises when an application uses user-supplied input to access objects directly. The term IDOR was popularized by its appearance in the OWASP 2007 Top Ten. However, it is just one example of many access control implementation mistakes that can lead to access controlsbeing circumvented. IDOR vulnerabilities are most commonly associated with horizontal privilege escalation, but they can also arise in relation to vertical privilege escalation.');
insert into posts (id, title, content) values ('7', 'Reverse Shell Attack', 'Reverse shell is a kind of “virtual” shellthat is initiated from a victim's computer to connect with attacker's computer. Once the connection is established, it allows attacker to send over commands to execute on the victim's computer and to get results back.');