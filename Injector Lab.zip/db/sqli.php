<?php
error_reporting(0);
$dbuser ='root';
$dbpass ='nyimalay';
$dbname ="theinjector";
$host = 'localhost';

$con = mysqli_connect($host,$dbuser,$dbpass);
if (mysqli_connect_errno())
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
else
{
    @mysqli_select_db($con, $dbname) or die ( "Unable to connect to the database: $dbname");
}


?>




 
