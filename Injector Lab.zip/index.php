<html>
<style>
body {
  background-color: black;
  color: green;

  
}
div { 
  border : 1px solid green; 
  
}
a {
  color:green;
  text-decoration: none;
}

#top    { 
  margin:0;  
  padding:1em; 
  }        
#south    { 
  margin:0; 
  padding:1em; 
  }        
#east     { 
  margin:0; 
  padding:1em;
  width:4em;
  height:22em;
  float:left;
  margin-right:1.1em
  }        
#west     {
  margin:0;
  padding:1em;
  width:4em;
  height:22em;
  float:right;
  margin-left:1.1em
  }        
#center   {
  margin:0;
  padding:1em;
  padding-bottom:0em;
  }        
#center:after    { 
  content:' '; 
  clear:both; 
  display:block;
  height:60%;
  overflow:hidden
  }
  #h {
    font-size: 35;
  }
</style>
<body>
  <center>
<?php include('lessons.php');?>
<div id="center">
<img src="img/author.png" height=130 width=150 alt="" /><br>
<p>I am CyberBullet.<br>Let's Improve Your Skill With My Lab.<br>Hacking Is Not Crim.<br>It Is An Art Of Exploiting</p>
</div>

<div id="south">
  <a>Hack Everythings , Harm Nothing</a>
</div>
</center>
</body>
</html>
