<html>
<title>Lesson-15</title>
<style>
body {
  background-color: black;
  color: green;

  
}
div { 
  border : 1px solid green; 
  
}
a {
  color:green;
  text-decoration: none;
}

#top    { 
  margin:0;  
  padding:1em; 
  }        
#south    { 
  margin:0; 
  padding:1em; 
  }        
#east     { 
  margin:0; 
  padding:1em;
  width:4em;
  height:22em;
  float:left;
  margin-right:1.1em
  }        
#west     {
  margin:0;
  padding:1em;
  width:4em;
  height:22em;
  float:right;
  margin-left:1.1em
  }        
#center   {
  margin:0;
  padding:1em;
  padding-bottom:0em;
  }        
#center:after    { 
  content:' '; 
  clear:both; 
  display:block;
  height:60%;
  overflow:hidden
  }
  #h {
    font-size: 35;
  }
</style>
<body>
  <center>
<?php include('lessons.php');?>
<div id="center">
<div class="container-narrow">
		
		<div class="jumbotron">
			<p class="lead" style="color:skyblue;">
				Inject The Update Query
			</p>
<p class="lead" style="color:skyblue;">
				You are logged in as guest with the password guest,You can Change the guest user's password
			</p>
        </div>
		
		<div class="response">
		<form method="POST" autocomplete="off">
			<p style="color:white">
			<input type="text" id="uid" name="opass" placeholder="Old Paswword"><br /></br />
				<input type="password" id="password" name="npass" placeholder="New Password">
			</p>
			<br />
			<p>
			<input type="submit" value="Update"/> 
			<input type="reset" value="Reset"/>
			</p>
		</form>
        </div>
    <?php
include("db/sqli.php");
if (!empty($_GET['msg'])) {
    echo "<font style=\"color:#FF0000\">Please login to continue.<br\></font\>";
}

if (!empty($_REQUEST['npass'])) {
$opass = $_REQUEST['opass'];
$npass = $_REQUEST['npass'];
$q = "SELECT uname from users WHERE pass='$opass'";
$sql=mysqli_query($con, $q);
$row = mysqli_fetch_array($sql, MYSQLI_BOTH);
	if($row)
	{
$uname = $row['0'];
$q = "UPDATE users SET pass='$npass' WHERE uname='$uname'";
$sql = mysqli_query($con, $q);
if ($sql){
echo "Password Have been changed";
}else{
echo "Password didn't changed";
print_r(mysqli_error($con));  
}
  	}
	else 
	{
	print_r(mysqli_error($con));  

	}
}


//}
?>
</div>

<div id="south">
  <a>Hack Everythings , Harm Nothing</a>
</div>
</center>
</body>
</html>
