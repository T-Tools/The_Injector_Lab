<html>
<title>Lesson-4</title>
<style>
body {
  background-color: black;
  color: green;

  
}
div { 
  border : 1px solid green; 
  
}
a {
  color:green;
  text-decoration: none;
}

#top    { 
  margin:0;  
  padding:1em; 
  }        
#south    { 
  margin:0; 
  padding:1em; 
  }        
#east     { 
  margin:0; 
  padding:1em;
  width:4em;
  height:22em;
  float:left;
  margin-right:1.1em
  }        
#west     {
  margin:0;
  padding:1em;
  width:4em;
  height:22em;
  float:right;
  margin-left:1.1em
  }        
#center   {
  margin:0;
  padding:1em;
  padding-bottom:0em;
  }        
#center:after    { 
  content:' '; 
  clear:both; 
  display:block;
  height:60%;
  overflow:hidden
  }
  #h {
    font-size: 35;
  }
</style>
<body>
  <center>
<?php include('lessons.php');?>
<div id="center">
<?php
include("db/sqli.php");
if(isset($_GET['id']))
{
$id=$_GET['id'];

$f=fopen('Logs/log-4.txt','a');
fwrite($f,'ID:'.$id."\n");
fclose($f);
$id = '"'.$id.'"';
$query="SELECT * FROM posts WHERE Id=($id)";
$sql=mysqli_query($con, $query);
$row = mysqli_fetch_array($sql, MYSQLI_BOTH);

	if($row)
	{
  echo "<h3 style='color:blue;'>" . $row['1'] . "</h3><br>";
  echo $row['2'];
  	}
	else 
	{
	print_r(mysqli_error($con));  
	}
}
	else { echo "Please input the ID as parameter with numeric value";}
?>
</div>

<div id="south">
  <a>Hack Everythings , Harm Nothing</a>
</div>
</center>
</body>
</html>
