<html>
<title>Lesson-12</title>
<style>
body {
  background-color: black;
  color: green;

  
}
div { 
  border : 1px solid green; 
  
}
a {
  color:green;
  text-decoration: none;
}

#top    { 
  margin:0;  
  padding:1em; 
  }        
#south    { 
  margin:0; 
  padding:1em; 
  }        
#east     { 
  margin:0; 
  padding:1em;
  width:4em;
  height:22em;
  float:left;
  margin-right:1.1em
  }        
#west     {
  margin:0;
  padding:1em;
  width:4em;
  height:22em;
  float:right;
  margin-left:1.1em
  }        
#center   {
  margin:0;
  padding:1em;
  padding-bottom:0em;
  }        
#center:after    { 
  content:' '; 
  clear:both; 
  display:block;
  height:60%;
  overflow:hidden
  }
  #h {
    font-size: 35;
  }
</style>
<body>
  <center>
<?php include('lessons.php');?>
<div id="center">
<div class="container-narrow">
		
		<div class="jumbotron">
			<p class="lead" style="color:skyblue;">
				Simple Authentication Bypass
			</p>
        </div>
		
		<div class="response">
		<form method="POST" autocomplete="off">
			<p style="color:white">
			<input type="text" id="uid" name="uid" placeholder="Username"><br /></br />
				<input type="password" id="password" name="password" placeholder="Password">
			</p>
			<br />
			<p>
			<input type="submit" value="Login"/> 
			<input type="reset" value="Reset"/>
			</p>
		</form>
        </div>
    <?php
include("db/sqli.php");
if (!empty($_GET['msg'])) {
    echo "<font style=\"color:#FF0000\">Please login to continue.<br\></font\>";
}

if (!empty($_REQUEST['uid'])) {
$username = mysqli_real_escape_string($con,$_REQUEST['uid']);
$pass = mysqli_real_escape_string($con,$_REQUEST['password']);

$q = "SELECT * FROM users where uname = '$username' AND pass = '$pass'" ;
//echo $q;
mysqli_query($con, "SET NAMES gbk");
	if (!mysqli_query($con,$q))
	{
		die('Error: ' . mysqli_error($con));
	}
	
	$result = mysqli_query($con,$q);
	$row_cnt = mysqli_num_rows($result);

	if ($row_cnt > 0) {
	
	$row = mysqli_fetch_array($result);
	
	if ($row){
echo "<h3 style='color:green;'>Login Success</h3>";
	
	}
}
	else{
		echo "<font style=\"color:red\"><br \>Invalid password!</font\>";

		
	}
}

//}
?>
</div>

<div id="south">
  <a>Hack Everythings , Harm Nothing</a>
</div>
</center>
</body>
</html>
